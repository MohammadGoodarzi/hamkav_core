from django.apps import AppConfig


class HamkavauthConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'HamkavAuth'
    # name = '_hamkavAuth'
    # HamkavAuth
